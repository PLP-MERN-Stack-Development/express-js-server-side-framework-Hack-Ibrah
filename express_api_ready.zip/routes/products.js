import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import validateProduct from '../middleware/validateProduct.js';
import NotFoundError from '../utils/NotFoundError.js';

const router = express.Router();

let products = [];

// GET all with filtering + pagination
router.get('/', (req, res) => {
  let result = [...products];
  const { category, page = 1, limit = 5 } = req.query;

  if (category) result = result.filter(p => p.category === category);

  const start = (page - 1) * limit;
  const paginated = result.slice(start, start + Number(limit));

  res.json({ total: result.length, page: Number(page), data: paginated });
});

// SEARCH
router.get('/search', (req, res) => {
  const { q } = req.query;
  if (!q) return res.json([]);

  const found = products.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  res.json(found);
});

// STATS
router.get('/stats', (req, res) => {
  const stats = {};
  products.forEach(p => {
    stats[p.category] = (stats[p.category] || 0) + 1;
  });
  res.json(stats);
});

// GET by ID
router.get('/:id', (req, res, next) => {
  const p = products.find(pr => pr.id === req.params.id);
  if (!p) return next(new NotFoundError('Product not found'));
  res.json(p);
});

// CREATE
router.post('/', validateProduct, (req, res) => {
  const newProduct = { id: uuidv4(), ...req.body };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

// UPDATE
router.put('/:id', validateProduct, (req, res, next) => {
  const index = products.findIndex(pr => pr.id === req.params.id);
  if (index === -1) return next(new NotFoundError('Product not found'));

  products[index] = { ...products[index], ...req.body };
  res.json(products[index]);
});

// DELETE
router.delete('/:id', (req, res, next) => {
  const index = products.findIndex(pr => pr.id === req.params.id);
  if (index === -1) return next(new NotFoundError('Product not found'));

  const deleted = products.splice(index, 1);
  res.json({ message: 'Deleted', deleted });
});

export default router;
