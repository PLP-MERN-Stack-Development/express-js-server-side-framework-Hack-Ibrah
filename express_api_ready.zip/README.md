# Week 2 Express.js API

## How to Run
```
npm install
npm start
```

## Endpoints
- GET /api/products
- GET /api/products/:id
- POST /api/products
- PUT /api/products/:id
- DELETE /api/products/:id
- GET /api/products/search?q=name
- GET /api/products/stats
