export default class ValidationError extends Error { constructor(msg){ super(msg); this.status=400; }}
